#include<stdio.h>

int main()
{
    int n;
    scanf("%d", &n);

    int a, b, c;
    a = n%10;
    n /= 10;
    b = n%10;
    n /= 10;
    c = n%10;
    n /= 10;

    //printf("%d%d%d%d\n", a, b, c, n);

    int max, smax;
    
    if(a > b)
    {
        max = a;
        smax = b;
    }
    else
    {
        max = b;
        smax = a;
    }
    // printf("%d\n", smax);
    if(c > max)
    {
        smax = max;
        max = c;
    }
    else if(c > smax)
    {
        smax = c;
    }
    // printf("%d\n", smax);
    if(n > max)
    {
        smax = max;
        max = n;
    }
    else if(n > smax)
    {
        smax = n;
    }

    printf("Second max: %d\n", smax);

    return 0;
}
#include<stdio.h>

int main()
{
    int n;
    printf("Salary: ");
    scanf("%d", &n);
    int salary = n;

    double tax = 0;

    int d = 300000;
    double i;

    n -= d;
    d = 100000;
    i = 0.05;
    if(n > 0 && n <= d) tax += n * i;
    else if(n > 0)
    {
        tax += d * i;

        n -= d;
        d = 300000;
        i = 0.1;
        if(n > 0 && n <= d) tax += n * i;
        else if(n > 0)
        {
            tax += d * i;

            n -= d;
            d = 400000;
            i = 0.15;
            if(n > 0 && n <= d) tax += n * i;
            else if(n > 0)
            {
                tax += d * i;

                n -= d;
                d = 500000;
                i = 0.2;
                if(n > 0 && n <= d) tax += n * i;
                else if(n > 0)
                {
                    tax += d * i;

                    n -= d;
                    i = 0.25;
                    tax += n * i;
                }
            }
        }
    }

    salary -= tax;
    printf("Income: %d\nTax: %lf\n", salary, tax);

    //main();

    return 0;
}
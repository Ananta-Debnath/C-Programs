#include<stdio.h>

int main()
{
    int n;
    printf("Salary: ");
    scanf("%d", &n);
    double tax = 0;

    if(n <= 300000) tax = 0;
    else if(n <= 400000) tax = (n-300000) * 0.05;
    else if(n <= 700000) tax = (100000 * 0.05) + ((n-400000) * 0.1);
    else if(n <= 1100000) tax = (100000 * 0.05) + (300000 * 0.1) + ((n-700000) * 0.15);
    else if(n <= 1600000) tax = (100000 * 0.05) + (300000 * 0.1) + (400000 * 0.15) + ((n-1100000) * 0.2);
    else tax = (100000 * 0.05) + (300000 * 0.1) + (400000 * 0.15) + (500000 * 0.2) + ((n-1600000) * 0.25);
    
    double salary = n - tax;
    printf("Income: %lf\nTax: %lf\n\n", salary, tax);

    //main();

    return 0;
}
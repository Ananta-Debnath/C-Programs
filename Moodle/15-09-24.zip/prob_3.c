#include<stdio.h>

int main()
{
    double a, b, c;
    printf("Numbers: ");
    scanf("%lf %lf", &a, &b);
    char op;
    printf("Operator: ");
    scanf("%*c%c", &op);

    switch (op)
    {
    case '+':
        c = a + b;
        break;

    case '-':
        c = a - b;
        break;

    case '*':
        c = a * b;
        break;

    case '/':
        c = a / b;
        break;
    
    default:
        printf("Operator Failure!!\n");
        break;
    }

    printf("Answer: %.2lf\n\n", c);

    //main();

    return 0;
}
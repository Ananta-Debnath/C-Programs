#include<stdio.h>
int main(){
    int m;scanf("%d",&m);
    printf("%d %p",m,&m);
}